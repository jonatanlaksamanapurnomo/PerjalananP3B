package com.example.t0216025;


import java.util.List;

interface IMainActivity  {
    public  void updateList(List<Food> foods);
}
