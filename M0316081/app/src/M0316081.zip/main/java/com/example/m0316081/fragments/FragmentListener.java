package com.example.m0316081.fragments;

public interface FragmentListener {
    void changePage(int page);
    void changeMessage(String message);
}
