package com.example.t0316081;

public interface FragmentListener {
    void changePage(int page , String text);
    void closeApplication();
}
