package com.example.t0116081.Model;

public class Angka {
    private int counter;

    public Angka(){
//        counter start with zero
        this.counter=0;
    }
    public int getAngka(){
        return this.counter;
    }
    public void setAngka(int angka){
        this.counter = angka;
    }

}
